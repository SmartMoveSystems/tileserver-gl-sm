#!/bin/bash

# ==========================================
#  MAPBOX STYLE CONVERTER (Complete Dark Mode)
# ==========================================

INPUT_FILE="${1:-style.json}"
OUTPUT_FILE="style.json"

# --- 0. Pre-flight Checks ---
if [ ! -f "$INPUT_FILE" ]; then
    echo "Error: Input file '$INPUT_FILE' not found."
    echo "Usage: ./convert_to_dark_complete.sh [input_filename]"
    exit 1
fi

# Check for potential Windows line ending issues
if file "$INPUT_FILE" | grep -q "CRLF"; then
    echo "⚠️  Warning: Input file seems to have Windows line endings (CRLF)."
    echo "   Run 'dos2unix $INPUT_FILE' if you encounter issues."
    sleep 1
fi

# ==========================================
#  🎨 COLOR MAPPING (Light -> Dark)
# ==========================================

# --- 1. Base Layers ---
OLD_BG="#f8f4f0"
NEW_BG="#1a1a1a"    # Dark Charcoal Background

# --- 2. Water ---
OLD_WATER="#a0c8f0"
NEW_WATER="#0d1d2d" # Deep Navy
OLD_WATER_HSL="hsl(210, 67%, 85%)"
NEW_WATER_HSL="hsl(210, 60%, 15%)"
OLD_WATER_BOUND="rgba(154, 189, 214, 1)"
NEW_WATER_BOUND="rgba(24, 60, 92, 1)"

# --- 3. Nature & Landcover ---
OLD_PARK="#d8e8c8"
NEW_PARK="#2a3325"  # Dark Moss Green
OLD_PARK_OUTLINE_6="hsla(96, 40%, 49%, 0.36)"
NEW_PARK_OUTLINE_6="hsla(96, 40%, 49%, 0.15)"
OLD_PARK_OUTLINE_8="hsla(96, 40%, 49%, 0.66)"
NEW_PARK_OUTLINE_8="hsla(96, 40%, 49%, 0.35)"

# Glacier/Ice (Bright white -> Light blue-grey)
OLD_GLACIER="#fff"
NEW_GLACIER="#e0f0ff"

# Wood (Green -> Darker Green)
OLD_WOOD="#6a4"
NEW_WOOD="#3a5a40"
OLD_WOOD_OUTLINE="hsla(0, 0%, 0%, 0.03)"
NEW_WOOD_OUTLINE="hsla(0, 0%, 100%, 0.05)"

# --- 4. Landuse Zones ---
# Residential (Light Orange -> Darker/Transparent)
OLD_RES_12="hsla(30, 19%, 90%, 0.4)"
NEW_RES_12="hsla(30, 10%, 20%, 0.4)"
OLD_RES_16="hsla(30, 19%, 90%, 0.2)"
NEW_RES_16="hsla(30, 10%, 20%, 0.2)"

# Commercial (Pinkish -> Dark Purple/Grey)
OLD_COM="hsla(0, 60%, 87%, 0.23)"
NEW_COM="hsla(0, 40%, 30%, 0.25)"

# Industrial (Yellowish -> Dark Brown/Grey)
OLD_IND="hsla(49, 100%, 88%, 0.34)"
NEW_IND="hsla(45, 50%, 25%, 0.30)"

# Cemetery (Grey -> Dark Grey)
OLD_CEM="#e0e4dd"
NEW_CEM="#3a3e38"

# Hospital (Pink -> Dark Reddish)
OLD_HOS="#fde"
NEW_HOS="#4d2a3a"

# School (Purple -> Dark Violet)
OLD_SCH="#f0e8f8"
NEW_SCH="#3a3040"

# Railway Landuse
OLD_RAIL_USE="hsla(30, 19%, 90%, 0.4)"
NEW_RAIL_USE="hsla(30, 5%, 20%, 0.4)"

# --- 5. Buildings ---
OLD_BLD_LIGHT="#f2eae2"
NEW_BLD_LIGHT="#2b2b2b"
OLD_BLD_DARK="#dfdbd7"
NEW_BLD_DARK="#3d3d3d"

# --- 6. Transportation ---
# Tunnels/Minor Roads
OLD_TUNNEL_CASING="#cfcdca"
NEW_TUNNEL_CASING="#404040"
OLD_ROAD_MINOR="#fff"
NEW_ROAD_MINOR="#444444"
OLD_ROAD_PATH="#cba"
NEW_ROAD_PATH="#666666"

# Secondary/Tertiary (Yellowish -> Grey)
OLD_ROAD_SEC="#fea"
NEW_ROAD_SEC="#707070"
OLD_ROAD_SEC_CASING="#e9ac77"
NEW_ROAD_SEC_CASING="#4a4a4a"
OLD_ROAD_SEC_TUNNEL="#fff4c6"
NEW_ROAD_SEC_TUNNEL="#555555"

# Motorway/Trunk (Orange -> Darker Grey/Orange)
OLD_ROAD_HWY="#fc8"
NEW_ROAD_HWY="#a86e32" # Muted Orange/Brown
OLD_ROAD_HWY_TUNNEL="#ffdaa6"
NEW_ROAD_HWY_TUNNEL="#8c5e2a"
OLD_ROAD_TRUNK_BRIDGE="hsl(28, 76%, 67%)"
NEW_ROAD_TRUNK_BRIDGE="hsl(28, 50%, 45%)"

# Railways (Grey -> Darker Grey)
OLD_RAIL_1="#bbb"
NEW_RAIL_1="#555"
OLD_RAIL_2="hsla(0, 0%, 73%, 0.77)"
NEW_RAIL_2="hsla(0, 0%, 40%, 0.77)"
OLD_RAIL_3="hsla(0, 0%, 73%, 0.68)"
NEW_RAIL_3="hsla(0, 0%, 40%, 0.68)"

# Aeroways (White -> Grey)
OLD_AERO_FILL="rgba(255, 255, 255, 1)"
NEW_AERO_FILL="rgba(80, 80, 80, 1)"
OLD_AERO_LINE="rgba(153, 153, 153, 1)"
NEW_AERO_LINE="rgba(100, 100, 100, 1)"

# Highway Area
OLD_HWY_AREA="hsla(0, 0%, 89%, 0.56)"
NEW_HWY_AREA="hsla(0, 0%, 20%, 0.56)"

# Boundaries
OLD_BOUND_4="#9e9cab"
NEW_BOUND_4="#666666"
OLD_BOUND_2="hsl(248, 7%, 66%)"
NEW_BOUND_2="hsl(248, 5%, 40%)"

# --- 7. Labels & Icons ---
OLD_TEXT="#333"
NEW_TEXT="#e0e0e0"
OLD_TEXT_HALO_8="rgba(255,255,255,0.8)"
NEW_TEXT_HALO_8="rgba(0,0,0,0.9)"
OLD_TEXT_HALO_7="rgba(255,255,255,0.7)"
NEW_TEXT_HALO_7="rgba(0,0,0,0.8)"
OLD_TEXT_WATER="#74aee9"
NEW_TEXT_WATER="#4a8cc9"
OLD_TEXT_PLACE="#633"
NEW_TEXT_PLACE="#c9a0a0" # Light Reddish Grey
OLD_TEXT_ROAD="#765"
NEW_TEXT_ROAD="#999"
OLD_TEXT_PATH="hsl(30, 23%, 62%)"
NEW_TEXT_PATH="hsl(30, 10%, 60%)"
OLD_TEXT_NUM="rgba(0, 0, 0, .4)"
NEW_TEXT_NUM="rgba(255, 255, 255, .6)"
OLD_SHIELD_TEXT="rgba(0, 0, 0, 1)"
NEW_SHIELD_TEXT="rgba(255, 255, 255, 1)"


# ==========================================
#  ⚙️ PROCESSING LOGIC
# ==========================================

# Helper to escape regex characters
escape_regex() {
    echo "$1" | sed 's/\[/\\[/g' | sed 's/\]/\\]/g' | sed 's/(/\\(/g' | sed 's/)/\\)/g' | sed 's/\./\\./g' | sed 's/*/\*/g'
}

echo "Processing $INPUT_FILE..."

# Prepare sed command with all replacements
sed -E \
    -e "s/\"$OLD_BG\"/\"$NEW_BG\"/Ig" \
    -e "s/\"$OLD_WATER\"/\"$NEW_WATER\"/Ig" \
    -e "s/\"$(escape_regex "$OLD_WATER_HSL")\"/\"$NEW_WATER_HSL\"/Ig" \
    -e "s/\"$(escape_regex "$OLD_WATER_BOUND")\"/\"$NEW_WATER_BOUND\"/Ig" \
    -e "s/\"$OLD_PARK\"/\"$NEW_PARK\"/Ig" \
    -e "s/\"$(escape_regex "$OLD_PARK_OUTLINE_6")\"/\"$NEW_PARK_OUTLINE_6\"/Ig" \
    -e "s/\"$(escape_regex "$OLD_PARK_OUTLINE_8")\"/\"$NEW_PARK_OUTLINE_8\"/Ig" \
    -e "s/\"$OLD_GLACIER\"/\"$NEW_GLACIER\"/Ig" \
    -e "s/\"$OLD_WOOD\"/\"$NEW_WOOD\"/Ig" \
    -e "s/\"$(escape_regex "$OLD_WOOD_OUTLINE")\"/\"$NEW_WOOD_OUTLINE\"/Ig" \
    -e "s/\"$(escape_regex "$OLD_RES_12")\"/\"$NEW_RES_12\"/Ig" \
    -e "s/\"$(escape_regex "$OLD_RES_16")\"/\"$NEW_RES_16\"/Ig" \
    -e "s/\"$(escape_regex "$OLD_COM")\"/\"$NEW_COM\"/Ig" \
    -e "s/\"$(escape_regex "$OLD_IND")\"/\"$NEW_IND\"/Ig" \
    -e "s/\"$OLD_CEM\"/\"$NEW_CEM\"/Ig" \
    -e "s/\"$OLD_HOS\"/\"$NEW_HOS\"/Ig" \
    -e "s/\"$OLD_SCH\"/\"$NEW_SCH\"/Ig" \
    -e "s/\"$(escape_regex "$OLD_RAIL_USE")\"/\"$NEW_RAIL_USE\"/Ig" \
    -e "s/\"$OLD_BLD_LIGHT\"/\"$NEW_BLD_LIGHT\"/Ig" \
    -e "s/\"$OLD_BLD_DARK\"/\"$NEW_BLD_DARK\"/Ig" \
    -e "s/\"$OLD_TUNNEL_CASING\"/\"$NEW_TUNNEL_CASING\"/Ig" \
    -e "s/\"$OLD_ROAD_MINOR\"/\"$NEW_ROAD_MINOR\"/Ig" \
    -e "s/\"$OLD_ROAD_PATH\"/\"$NEW_ROAD_PATH\"/Ig" \
    -e "s/\"$OLD_ROAD_SEC\"/\"$NEW_ROAD_SEC\"/Ig" \
    -e "s/\"$OLD_ROAD_SEC_CASING\"/\"$NEW_ROAD_SEC_CASING\"/Ig" \
    -e "s/\"$OLD_ROAD_SEC_TUNNEL\"/\"$NEW_ROAD_SEC_TUNNEL\"/Ig" \
    -e "s/\"$OLD_ROAD_HWY\"/\"$NEW_ROAD_HWY\"/Ig" \
    -e "s/\"$OLD_ROAD_HWY_TUNNEL\"/\"$NEW_ROAD_HWY_TUNNEL\"/Ig" \
    -e "s/\"$(escape_regex "$OLD_ROAD_TRUNK_BRIDGE")\"/\"$NEW_ROAD_TRUNK_BRIDGE\"/Ig" \
    -e "s/\"$OLD_RAIL_1\"/\"$NEW_RAIL_1\"/Ig" \
    -e "s/\"$(escape_regex "$OLD_RAIL_2")\"/\"$NEW_RAIL_2\"/Ig" \
    -e "s/\"$(escape_regex "$OLD_RAIL_3")\"/\"$NEW_RAIL_3\"/Ig" \
    -e "s/\"$(escape_regex "$OLD_AERO_FILL")\"/\"$NEW_AERO_FILL\"/Ig" \
    -e "s/\"$(escape_regex "$OLD_AERO_LINE")\"/\"$NEW_AERO_LINE\"/Ig" \
    -e "s/\"$(escape_regex "$OLD_HWY_AREA")\"/\"$NEW_HWY_AREA\"/Ig" \
    -e "s/\"$OLD_BOUND_4\"/\"$NEW_BOUND_4\"/Ig" \
    -e "s/\"$(escape_regex "$OLD_BOUND_2")\"/\"$NEW_BOUND_2\"/Ig" \
    -e "s/\"$OLD_TEXT\"/\"$NEW_TEXT\"/Ig" \
    -e "s/\"$(escape_regex "$OLD_TEXT_HALO_8")\"/\"$NEW_TEXT_HALO_8\"/Ig" \
    -e "s/\"$(escape_regex "$OLD_TEXT_HALO_7")\"/\"$NEW_TEXT_HALO_7\"/Ig" \
    -e "s/\"$OLD_TEXT_WATER\"/\"$NEW_TEXT_WATER\"/Ig" \
    -e "s/\"$OLD_TEXT_PLACE\"/\"$NEW_TEXT_PLACE\"/Ig" \
    -e "s/\"$OLD_TEXT_ROAD\"/\"$NEW_TEXT_ROAD\"/Ig" \
    -e "s/\"$(escape_regex "$OLD_TEXT_PATH")\"/\"$NEW_TEXT_PATH\"/Ig" \
    -e "s/\"$(escape_regex "$OLD_TEXT_NUM")\"/\"$NEW_TEXT_NUM\"/Ig" \
    -e "s/\"$(escape_regex "$OLD_SHIELD_TEXT")\"/\"$NEW_SHIELD_TEXT\"/Ig" \
    "$INPUT_FILE" > "$OUTPUT_FILE"

# ==========================================
#  ✅ VERIFICATION
# ==========================================

if grep -q "$NEW_BG" "$OUTPUT_FILE"; then
    echo "Success! Dark theme saved to: $OUTPUT_FILE"
else
    echo "Warning: Script ran, but could not verify background color change."
fi

